import { afterEach } from 'vitest';
import { cleanup } from '@testing-library/react';
import '@testing-library/jest-dom'; // Import directly, no /matchers

// Cleanup after each test
afterEach(() => {
    cleanup();
});