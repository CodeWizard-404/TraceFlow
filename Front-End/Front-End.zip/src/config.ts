export const BASE_URL = import.meta.env.VITE_BASE_URL || 'http://192.168.1.14:5000/api';



